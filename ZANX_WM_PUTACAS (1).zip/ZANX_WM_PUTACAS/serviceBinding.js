function initModel(){var a="/sap/opu/odata/sap/ZWM_ZW04_PUTAWAY_CASE_SRV/";var e=new sap.ui.model.odata.ODataModel(a,true);sap.ui.getCore().setModel(e)}
//# sourceMappingURL=serviceBinding.js.map